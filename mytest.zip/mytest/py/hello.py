import sklearn

a = 10

def sayHello(name):
    return name + "haha"